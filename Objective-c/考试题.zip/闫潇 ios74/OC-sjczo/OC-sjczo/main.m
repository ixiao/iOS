//
//  main.m
//  OC-sjczo
//
//  Created by 徐赢 on 14-9-11.
//  Copyright (c) 2014年 徐赢. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    //1,有如下格式字符串，要求将其转换为键值对形势存入字典
    NSString * str = @"a=1|b=2|c=2";
    NSMutableDictionary * mDic = [NSMutableDictionary dictionary];
    NSArray * arr = [str componentsSeparatedByString:@"|"];
    for (NSString * str in arr)
    {
        NSRange  range = [str rangeOfString:@"="];
        NSString * key = [str substringToIndex:range.location];
        NSString * value = [str substringFromIndex:range.location+range.length];
        [mDic setObject:value forKey:key];
    }
    NSLog(@"%@",mDic);
    
    //2，有如下字典,将其转换为上述字符串形势
    NSDictionary * dic = @{@"a": @"1",@"b":@"2"};
    NSMutableString  * mStr = [NSMutableString new];
    BOOL isFirst = YES;
    for (NSString * key in dic)
    {
        NSString * value = dic[key];
        if (isFirst)
        {
            isFirst = NO;
            [mStr appendFormat:@"%@=%@",key,value];
        }
        else
        {
            [mStr appendFormat:@"&%@=%@",key,value];
        }
        
    }
    NSLog(@"%@",mStr);
    
    
    
    return 0;
}

