//
//  ViewController.h
//  OC-ywlj5
//
//  Created by 徐赢 on 14-9-11.
//  Copyright (c) 2014年 徐赢. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SourceManager.h"
//要求：使用SDK中给的组件完成如下功能

//1,当点击按钮时，使用sourceManage对象请求url
//2,如果请求成功，把url显示在label上，并且用player对象播放该url
//3，如果请求失败，在label上显示失败原因
//4，当播放完成时，在label上显示播放完成

@interface ViewController : NSObject<SourceManagerDelegate>

@end
