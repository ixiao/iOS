//
//  ViewController.m
//  OC-ywljt
//
//  Created by 徐赢 on 14-9-11.
//  Copyright (c) 2014年 徐赢. All rights reserved.
//

#import "ViewController.h"

#import "Label.h"
#import "Button.h"

@interface ViewController ()

@property(nonatomic,strong)Label * label;
@property(nonatomic,strong)Button * buttonA;
@property(nonatomic,strong)Button * buttonB;

-(void)tapButtonA:(Button *)button;
-(void)tapButtonB:(Button *)button;

@end

@implementation ViewController

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.label = [[Label alloc]init];
        
        self.buttonA = [[Button alloc]init];
        [self.buttonA setTitle:@"A"];
        [self.buttonA addTapTarget:self Action:@selector(tapButtonA:)];
        self.buttonB = [[Button alloc]init];
        [self.buttonB setTitle:@"B"];
        [self.buttonB addTapTarget:self Action:@selector(tapButtonB:)];
    }
    return self;
}

-(void)tapButtonA:(Button *)button
{
    [self.label setText:@"A"];
}
-(void)tapButtonB:(Button *)button
{
    [self.label setText:@"B"];
}




@end