//
//  ViewController.h
//  OC-ywljt
//
//  Created by 徐赢 on 14-9-11.
//  Copyright (c) 2014年 徐赢. All rights reserved.
//

#import <Foundation/Foundation.h>


//要求，视图中有一个Label，两个按钮
//一个按钮的title为A，另一个按钮的title为B
//当点击按钮A的时候，label显示A，点击B时显示B

@interface ViewController : NSObject

@end
