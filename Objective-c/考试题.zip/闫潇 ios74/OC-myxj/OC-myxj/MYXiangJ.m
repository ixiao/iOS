//
//  MYXiangJ.m
//  OC-myxj
//
//  Created by 闫潇 on 14/12/16.
//  Copyright (c) 2014年 徐赢. All rights reserved.
//

#import "MYXiangJ.h"
@interface MYXiangJ ()
@property (nonatomic,strong) MeiYan * MY;
@end
@implementation MYXiangJ
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.MY = [MeiYan new];
    }
    return self;
}
-(void)takePhoto
{
    [super takePhoto];
    [self.MY meiyan];
}
@end
