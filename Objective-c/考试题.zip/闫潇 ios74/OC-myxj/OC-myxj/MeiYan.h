//
//  MeiYan.h
//  OC-myxj
//
//  Created by 徐赢 on 14-9-12.
//  Copyright (c) 2014年 徐赢. All rights reserved.
//

#import <Foundation/Foundation.h>

//美颜模块，具有美颜功能

@interface MeiYan : NSObject

-(void)meiyan;

@end
