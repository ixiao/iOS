//
//  MYXiangJ.h
//  OC-myxj
//
//  Created by 闫潇 on 14/12/16.
//  Copyright (c) 2014年 徐赢. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Xiangji.h"
#import "MeiYan.h"
@interface MYXiangJ : Xiangji

@end
