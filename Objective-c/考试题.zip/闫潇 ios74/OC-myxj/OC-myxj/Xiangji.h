//
//  Xiangji.h
//  OC-myxj
//
//  Created by 徐赢 on 14-9-12.
//  Copyright (c) 2014年 徐赢. All rights reserved.
//

#import <Foundation/Foundation.h>

//相加，具有拍照功能
@interface Xiangji : NSObject

-(void)takePhoto;

@end
