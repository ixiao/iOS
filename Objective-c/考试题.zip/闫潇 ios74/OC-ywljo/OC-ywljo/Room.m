//
//  Room.m
//  OC-ywljo
//
//  Created by 徐赢 on 14-9-11.
//  Copyright (c) 2014年 徐赢. All rights reserved.
//

#import "Room.h"

#import "Kongtiao.h"
#import "Wenduji.h"


@interface Room ()

@property(nonatomic,strong)Kongtiao * kt;

@property(nonatomic,strong)Wenduji *wdj;
-(void)wenduChange:(Wenduji *)wdj;


@end

@implementation Room

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.kt = [[Kongtiao alloc]init];
        
        self.wdj = [[Wenduji alloc]init];
        [self.wdj addWenduChangeTarget:self Action:@selector(wenduChange:)];
    }
    return self;
}

-(void)wenduChange:(Wenduji *)wdj
{
    if ([wdj.wenduValue intValue]< 24)
    {
        [self.kt zhire];
    }
    else if ([wdj.wenduValue intValue]<28)
    {
        [self.kt stop];
    }
    else
    {
        [self.kt zhileng];
    }
}

@end
