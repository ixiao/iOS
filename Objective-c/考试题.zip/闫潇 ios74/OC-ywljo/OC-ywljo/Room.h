//
//  Room.h
//  OC-ywljo
//
//  Created by 徐赢 on 14-9-11.
//  Copyright (c) 2014年 徐赢. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "Kongtiao.h"

//要求：使用SDK中所给的空调和温度计，使房间温度保持在24-28度之间
@interface Room : NSObject

@end
