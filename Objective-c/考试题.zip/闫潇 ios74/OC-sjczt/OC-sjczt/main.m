//
//  main.m
//  OC-sjczt
//
//  Created by 徐赢 on 14-9-11.
//  Copyright (c) 2014年 徐赢. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{


    
    NSArray * arr = @[@{@"key": @"name",@"value":@"iPhone"},@{@"key": @"age",@"value":@"20"}];
    //将上述数组中的数据通过代码整理成如下格式
   // NSDictionary * dic = @{@"a": @"1",@"b":@"2"}；
    NSMutableDictionary * mDic = [NSMutableDictionary new];
    for (NSDictionary * dic in arr)
    {
        NSString * key = dic[@"key"];
        NSString * value = dic[@"value"];
        [mDic setValue:value forKey:key];
    }
    NSLog(@"%@",mDic);
    

    return 0;
}

