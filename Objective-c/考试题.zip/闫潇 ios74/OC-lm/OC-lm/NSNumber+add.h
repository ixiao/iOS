//
//  NSNumber+add.h
//  OC-lm
//
//  Created by 闫潇 on 14/12/16.
//  Copyright (c) 2014年 徐赢. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSNumber (add)
-(BOOL)isBigger:(NSNumber *)num;

@end
