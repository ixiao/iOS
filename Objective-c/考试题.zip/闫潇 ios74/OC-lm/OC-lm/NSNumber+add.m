//
//  NSNumber+add.m
//  OC-lm
//
//  Created by 闫潇 on 14/12/16.
//  Copyright (c) 2014年 徐赢. All rights reserved.
//

#import "NSNumber+add.h"

@implementation NSNumber (add)
-(BOOL)isBigger:(NSNumber *)num
{
    int a = [num intValue];
    int b = [self intValue];
    if (a<b) {
        return YES;
    }
    else
        return NO;
}
@end
