//
//  main.m
//  OC-lm
//
//  Created by 徐赢 on 14-9-11.
//  Copyright (c) 2014年 徐赢. All rights reserved.
//

#import <Foundation/Foundation.h>

//为NSNumber添加一个类目方法
//-(BOOL)isBigger:(NSNumber *)num;
//功能如下
//NSNumber * num1 = [NSNumber numberWithInt:1];
//NSNumber * num2 = [NSNumber numberWithInt:2];
//BOOL isB = [num1 isBigger:num2];
//打印isB的值为NO
#import "NSNumber+add.h"
int main(int argc, const char * argv[])
{

    @autoreleasepool {
        NSNumber * num1 = [NSNumber numberWithInt:1];
        NSNumber * num2 = [NSNumber numberWithInt:2];
        BOOL isB=[num1 isBigger:num2];
        NSLog(@"%d",isB);
    }
    return 0;
}

