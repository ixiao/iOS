//
//  ViewController.h
//  OC-ywlj3
//
//  Created by 徐赢 on 14-9-11.
//  Copyright (c) 2014年 徐赢. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SourceManager.h"
//要求，使用SDK中提供的组件实现以下业务逻辑
//1,当点击按钮时，让sourceManager请求数据
//2,如果请求成功，把数据显示在label上
//3，如果请求失败，把失败原因显示在label上


@interface ViewController : NSObject<SourceManagerDelegate>

@end
