//
//  ViewController.m
//  OC-ywlj3
//
//  Created by 徐赢 on 14-9-11.
//  Copyright (c) 2014年 徐赢. All rights reserved.
//

#import "ViewController.h"
#import "Button.h"
#import "Label.h"

//1,当点击按钮时，让sourceManager请求数据
//2,如果请求成功，把数据显示在label上
//3，如果请求失败，把失败原因显示在label上
@interface ViewController ()
@property (nonatomic,strong) Button * button;
@property (nonatomic,strong) Label * label;
@property (nonatomic,strong) SourceManager * smn;
-(void)doButton:(Button *)sender;//点击按钮的方法
@end

@implementation ViewController
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.button = [Button new];
        self.label = [Label new];
        [self.button addTapTarget:self Action:@selector(doButton:)];//点击按钮
        
        self.smn = [SourceManager new];
        self.smn.delegate=self;//绑定委托
        
    }
    return self;
}
-(void)doButton:(Button *)sender
{
    [self.smn qingqiuString];//委托请求数据
}
-(void)sourceManager:(SourceManager *)sm didReceiveString:(NSString *)string
{
    [self.label setText:string];
}
-(void)sourceManager:(SourceManager *)sm didReceiveError:(NSError *)error
{
    NSString * err = [error localizedDescription];
    [self.label setText:err];
}
@end
